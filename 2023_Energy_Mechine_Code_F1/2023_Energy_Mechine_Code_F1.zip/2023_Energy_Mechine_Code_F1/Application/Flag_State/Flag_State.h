#ifndef __FLAG_STATE_H
#define __FLAG_STATE_H

#include "CAN_receive.h"
#include "CAN_send.h"



void Board_Order_info_Init(Board_Order_info_t *Order);
void Big_Fu_info_Init(Big_Fu_info_t *Big_Fu);

#endif
