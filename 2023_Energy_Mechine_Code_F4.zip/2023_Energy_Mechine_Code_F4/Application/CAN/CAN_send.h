#ifndef  _CAN_SEND_H
#define  _CAN_SEND_H

#include "main.h"
#include "CAN_receive.h"


uint8_t Board_Tx(uint32_t std, uint8_t *data,char hcan,uint32_t DL);




#endif



