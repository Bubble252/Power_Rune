#ifndef __CAN_POTOCAL_H
#define __CAN_POTOCAL_H

/* Includes ------------------------------------------------------------------*/
#include "CAN_receive.h"
#include "CAN_send.h"
#include "Motor.h"


void Board_Info_Tx(void);
/* Exported functions --------------------------------------------------------*/

#endif

